package com.petcommunity.pet_lover_server_side;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetLoverServerSideApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetLoverServerSideApplication.class, args);
	}

}
