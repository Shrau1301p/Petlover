package com.petcommunity.pet_lover_server_side;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetLoverServerSideApplicationTests {

	@Test
	void contextLoads() {
	}

}
